# Snowkite Risk Dashboard

This app predicts avalanche risk (ARI) and persistent weak layer risk (WLRI) in the Nevados de Chillán region.

## How to Use

1. Upload an Excel file with your weekly snow and weather data.
2. The app will automatically calculate risk levels.
3. You can run it locally or deploy it on Streamlit Cloud.

## Installation

```bash
pip install streamlit pandas altair openpyxl
streamlit run app.py
```

## Deployment (Streamlit Cloud)

1. Create a GitHub repo and upload `app.py`, `requirements.txt`, and this README.
2. Deploy using [streamlit.io/cloud](https://streamlit.io/cloud)
